//
//  CreateContactViewController.swift
//  FinalProject
//
//  Created by Shiva on 10/11/21.
//

import UIKit

/// This view controller used to create and update Contact
class ContactDetailsViewController: UIViewController {
    
    /// defines view type
    enum ViewType {
        case edit
        case create
    }
    
    @IBOutlet weak var contactNameTextField: UITextField!
    @IBOutlet weak var contactPhoneNumberTextField: UITextField!
    
    @IBOutlet weak var deleteButton: UIButton!
    /// Called on saving of new Contact
    var contactCreationOnSuccess: ((Contact)->())?
    /// Called on saving of Delete Contact
    var contactDeleteOnSuccess: ((Contact)->())?
    /// called on editing on exiting Contact completes
    var contactEditSuccess: (()->())?
    
    var viewType: ViewType = .create
    var selectedContact: Contact?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        addNavigationRightBarButtonItem()
    }
    
    /// Used to setup UI
    func setupUI() {
        switch viewType {
        case .edit:
            title = "Edit"
            prefillContactDetails()
            deleteButton.isHidden = false
        case .create:
            title = "Add Contact"
        }
    }
    
    /// preefills selected Contact details on text fields
    func prefillContactDetails() {
        guard let Contact = selectedContact else { return }
        contactNameTextField.text  = Contact.name
        contactPhoneNumberTextField.text = Contact.phoneNumber
    }
    
    ///  adds save button to navigation bar
    func addNavigationRightBarButtonItem() {
        let addButton = UIBarButtonItem.init(
            title: deleteButton.isHidden ? "Add" : "Save",
              style: .done,
              target: self,
              action: #selector(saveButtonTapped(sender:))
        )
        self.navigationItem.rightBarButtonItem = addButton
    }
    
    /// Create/updates a Contact
    @objc func saveButtonTapped(sender: UIBarButtonItem) {
        switch viewType {
        case .edit:
            selectedContact?.name = contactNameTextField.text ?? ""
            selectedContact?.phoneNumber = contactPhoneNumberTextField.text ?? ""
            contactEditSuccess?()
            navigationController?.popViewController(animated: true)
        case .create:
            let contact = Contact(name: contactNameTextField.text ?? "", phoneNumber: contactPhoneNumberTextField.text ?? "")
            contactCreationOnSuccess?(contact)
            navigationController?.popViewController(animated: true)
        }
    }

    @IBAction func deleteContactOnTapped(_ sender: Any) {
        if let contact = selectedContact {
            contactDeleteOnSuccess?(contact)
            navigationController?.popViewController(animated: true)
        }
        
    }
}
