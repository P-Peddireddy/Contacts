//
//  ContactListViewController.swift
//  FinalProject
//
//  Created by Shiva on 09/11/21.
//

import UIKit

/// This View Controller is used to show contacts list
class ContactListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var nodataLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var isSearch : Bool = false
    var filterContactList = [Contact]()
    var contactList: [Contact] = [] {
        didSet {
            /// Hide/showing nodata label when contact list udpated
            nodataLabel.isHidden = !contactList.isEmpty
            tableView.isHidden = false
        }
    }

    //  MARK:  - Viewlife Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
        title =  "Contacts"
        addNavigationRightBarButtonItem()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        isSearch = false
        self.tableView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        searchBar.searchTextField.text = ""
        self.view.endEditing(true)
    }
    
    /// adding new contact button to navigation bar
    func addNavigationRightBarButtonItem() {
        let addButton = UIBarButtonItem.init(
              image: UIImage(systemName: "plus"),
              style: .done,
              target: self,
              action: #selector(addNewcontactButtonAction(sender:))
        )
        self.navigationItem.rightBarButtonItem = addButton
    }
    
    /// redirects user  to contact add screen ans
    @objc func addNewcontactButtonAction(sender: UIBarButtonItem) {
        /// Pushing  to new contact view controller to create contacts
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let contactDetailsViewController = storyboard.instantiateViewController(withIdentifier: "contactDetailsViewController") as! ContactDetailsViewController
        contactDetailsViewController.viewType = .create
        contactDetailsViewController.contactCreationOnSuccess = { contact in
            self.isSearch = false
            self.contactList.append(contact)
            self.tableView.reloadData()
        }
        self.navigationController?.pushViewController(contactDetailsViewController, animated: true)
    }
    
    /// setting table view controller for table cell
    func setUpTableView() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    // MARK: - TableViewDelegate Methods
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isSearch ? filterContactList.count : contactList.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        /// redirecting user to contact details screen to update details
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let contactDetailsViewController = storyboard.instantiateViewController(withIdentifier: "contactDetailsViewController") as! ContactDetailsViewController
        contactDetailsViewController.viewType = .edit
        contactDetailsViewController.selectedContact = isSearch ? filterContactList[indexPath.row] : contactList[indexPath.row]
        /// reloading table view on contact details update
        contactDetailsViewController.contactEditSuccess = {
            self.tableView.reloadData()
        }
        // reloading table view on contact details deleting
        contactDetailsViewController.contactDeleteOnSuccess = { selectConatct in
            self.contactList.removeAll { contact -> Bool in
                contact.name == selectConatct.name
            }
            tableView.reloadData()
        }
        self.navigationController?.pushViewController(contactDetailsViewController, animated: true)
    }
    

    // MARK: - TableViewDataSource Methods

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: "Cell")
        let contact = isSearch ? filterContactList[indexPath.row] : contactList[indexPath.row]
        cell.textLabel?.text = contact.name
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        //deleting selected contact from contacts array
        if editingStyle == .delete {
            contactList.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }

}

extension ContactListViewController: UISearchBarDelegate{
    //MARK: UISearchbar delegate
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        isSearch = true
    }
       
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
           searchBar.resignFirstResponder()
           isSearch = false
    }
       
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
           searchBar.resignFirstResponder()
           isSearch = false
    }
       
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
           searchBar.resignFirstResponder()
           isSearch = false
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.count == 0 {
            isSearch = false
            self.tableView.reloadData()
        } else {
            filterContactList = contactList.filter({ (text) -> Bool in
                let tmp: NSString = text.name as NSString
                let range = tmp.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
                return range.location != NSNotFound
            })
            if(filterContactList.count == 0){
                isSearch = false
            } else {
                isSearch = true
            }
            self.tableView.reloadData()
        }
    }

}

