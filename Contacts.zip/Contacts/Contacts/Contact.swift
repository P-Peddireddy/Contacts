//
//  Customer.swift
//  FinalProject
//
//  Created by Shiva on 10/11/21.
//

import Foundation

class Contact {
    var name: String
    var phoneNumber: String
    
    init(name: String, phoneNumber: String) {
        self.name = name
        self.phoneNumber = phoneNumber
    }
}
