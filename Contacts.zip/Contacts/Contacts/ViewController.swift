//
//  ViewController.swift
//  Contacts
//
//  Created by GGKU5MACBOOK036 on 11/12/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

